

// Conectar a MetaMask
async function connect() {
    if (!window.ethereum) return alert("⚠️ Instala MetaMask");

    await ethereum.request({ method: "eth_requestAccounts" });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
    contract = new ethers.Contract(registroEstudiantesAddress, registroEstudiantesABI, signer);

    const cuenta = await signer.getAddress();
    console.log("✅ Conectado a MetaMask:", cuenta);

    // Obtener admin del contrato
    try {
        adminAddress = await contract.admin();
        console.log("Admin del contrato:", adminAddress);
    } catch (err) {
        console.error("❌ No se pudo obtener admin del contrato:", err);
        return;
    }

    // Verificar si la cuenta conectada es admin
    await verificarAdmin();

    // Detectar cambio de cuentas en MetaMask
    window.ethereum.on("accountsChanged", async (accounts) => {
        if (accounts.length > 0) {
            signer = provider.getSigner();
            contract = new ethers.Contract(registroEstudiantesAddress, registroEstudiantesABI, signer);
            console.log("🔄 Cambiaste de cuenta:", accounts[0]);
            await verificarAdmin();
        }
    });
}

// Verificar admin
async function verificarAdmin() {
    if (!contract || !adminAddress) return;
    const cuenta = await signer.getAddress();
    const esAdmin = cuenta.toLowerCase() === adminAddress.toLowerCase();

    // Habilitar botones solo si es admin
    document.getElementById("Registrar").disabled = !esAdmin;
    document.getElementById("Actualizar").disabled = !esAdmin;
    document.getElementById("Eliminar").disabled = !esAdmin;

    console.log("Cuenta conectada:", cuenta);
    console.log("Admin contrato :", adminAddress);
    console.log(esAdmin ? "✅ Eres admin" : "⚠️ No eres admin");
}

// Función de prueba para admin
async function pruebaAdmin() {
    if (!contract) await connect();
    const admin = await contract.admin();
    console.log("Admin desde pruebaAdmin():", admin);
}

// --- Funciones CRUD de estudiantes --- 

// Registrar estudiante
async function registrar(event) {
    event.preventDefault();

    const name = document.getElementById("nombreEstudiante").value.trim();
    const phone = document.getElementById("telefono").value.trim();
    const wallet = document.getElementById("wallet").value.trim();

    if (!name || !phone || !wallet) return alert("Por favor completa todos los campos");

    try {
        if (!contract) await connect();

        const existingStudent = await contract.getStudentByWallet(wallet).catch(() => null);
        if (existingStudent && existingStudent[3] !== "") {
            alert("❌ No se puede registrar: Wallet ya existe");
            return;
        }

        const tx = await contract.registerStudent(wallet, name, phone);
        await tx.wait();

        alert("✅ Estudiante registrado correctamente!");
        limpiarCampos();
        mostrarEstudiantes();
    } catch (err) {
        console.error("❌ Error en registro:", err);
        alert("Error al registrar (revisa la consola para más detalles)");
    }
}

// Actualizar estudiante
async function actualizar(event) {
    event.preventDefault();

    const wallet = document.getElementById("wallet").value.trim();
    const newName = document.getElementById("nombreEstudiante").value.trim();
    const newPhone = document.getElementById("telefono").value.trim();

    if (!wallet || !newName || !newPhone) return alert("Por favor completa todos los campos");

    try {
        if (!contract) await connect();

        const student = await contract.getStudentByWallet(wallet).catch(() => null);
        if (!student) return alert("❌ Wallet no registrada");

        const id = student[0];
        const tx = await contract.updateStudent(id, newName, newPhone);
        await tx.wait();

        alert("✅ Estudiante actualizado correctamente!");
        limpiarCampos();
        mostrarEstudiantes();
    } catch (err) {
        console.error("❌ Error en actualización:", err);
        alert("Error al actualizar (revisa la consola para más detalles)");
    }
}

// Buscar estudiante
async function buscar(event) {
    event.preventDefault();

    const wallet = document.getElementById("wallet").value.trim();
    if (!wallet) return alert("Por favor ingresa una wallet");

    try {
        if (!contract) await connect();

        const student = await contract.getStudentByWallet(wallet).catch(() => null);
        if (!student) {
            alert("❌ Wallet no registrada");
            limpiarCampos();
            return;
        }

        document.getElementById("nombreEstudiante").value = student[1];
        document.getElementById("telefono").value = student[3];
    } catch (err) {
        console.error("❌ Error al buscar datos:", err);
        alert("Error al buscar datos (revisa la consola para más detalles)");
    }
}

// Eliminar estudiante
async function eliminar(event) {
    event.preventDefault();

    const wallet = document.getElementById("wallet").value.trim();
    if (!wallet) return alert("Por favor ingresa una wallet");

    try {
        if (!contract) await connect();

        const student = await contract.getStudentByWallet(wallet).catch(() => null);
        if (!student) return alert("❌ Wallet no registrada");

        const tx = await contract.deleteStudent(wallet);
        await tx.wait();

        alert("✅ Estudiante eliminado correctamente!");
        limpiarCampos();
        mostrarEstudiantes();
    } catch (err) {
        console.error("❌ Error al eliminar estudiante:", err);
        alert("Error al eliminar estudiante (revisa la consola para más detalles)");
    }
}

// Limpiar campos del formulario
function limpiarCampos() {
    document.getElementById("nombreEstudiante").value = "";
    document.getElementById("telefono").value = "";
    document.getElementById("wallet").value = "";
}

// Mostrar todos los estudiantes en tabla
async function mostrarEstudiantes() {
    if (!contract) await connect();

    try {
        const students = await contract.getAllStudents();
        const container = document.getElementById("tablainfo");

        let table = container.querySelector("table");
        if (!table) {
            table = document.createElement("table");
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Teléfono</th>
                        <th>Wallet</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;
            container.appendChild(table);
        }

        const tbody = table.querySelector("tbody");
        tbody.innerHTML = "";

        students.forEach(s => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${s.id}</td>
                <td>${s.name}</td>
                <td>${s.phone}</td>
                <td>${s.wallet}</td>
            `;
            tr.addEventListener("click", () => {
                document.getElementById("nombreEstudiante").value = s.name;
                document.getElementById("telefono").value = s.phone;
                document.getElementById("wallet").value = s.wallet;
            });
            tbody.appendChild(tr);
        });
    } catch (err) {
        console.error("❌ Error al mostrar estudiantes:", err);
    }
}

// --- Listeners ---
document.getElementById("Registrar").addEventListener("click", registrar);
document.getElementById("Actualizar").addEventListener("click", actualizar);
document.getElementById("Buscar").addEventListener("click", buscar);
document.getElementById("Eliminar").addEventListener("click", eliminar);
document.getElementById("Ver").addEventListener("click", mostrarEstudiantes);
document.getElementById("Limpiar").addEventListener("click", limpiarCampos);

// Conectar al cargar la página
window.addEventListener("load", async () => {
    await connect();
    await pruebaAdmin();
});
