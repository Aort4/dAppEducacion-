let provider;
let signer;
let contratoEstudiantes;
let contratoCursos;
let contratoNotas;
let contratoCertificados;

async function initContratos() {
    if (!window.ethereum) return alert("⚠️ Instala MetaMask");
    provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = provider.getSigner();

    contratoEstudiantes = new ethers.Contract(registroEstudiantesAddress, registroEstudiantesABI, signer);
    contratoCursos = new ethers.Contract(registroCursosAddress, registroCursosABI, signer);
    contratoNotas = new ethers.Contract(registroNotasAddress, registroNotasABI, signer);
    contratoCertificados = new ethers.Contract(registroCertificadosAddress, registroCertificadosABI, signer);
}

async function cargarDatos() {
    const estudiantes = await contratoEstudiantes.getAllStudents();
    const cursos = await contratoCursos.obtenerCursos();
    const certificados = await contratoCertificados.obtenerTodosCertificados();
    const todasNotasRaw = await contratoNotas.obtenerTodasNotas(); 

    const body = $("#example tbody");
    body.empty();

    const idEstudiantesNotas = todasNotasRaw[0].map(id => id.toNumber());
    const notasPorEstudiante = todasNotasRaw[1]; 

    for (let est of estudiantes) {
        if (!est.exists) continue;
        const idEstudiante = est.id.toNumber();

        const certificadosEst = certificados.filter(c => c.idEstudiante.toNumber() === idEstudiante);

        if (certificadosEst.length === 0) {
            body.append(`
                <tr>
                    <td>${est.name}</td>
                    <td>${est.wallet}</td>
                    <td>${est.phone}</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                </tr>
            `);
        } else {
            let notasEstudiante = [];
            const idx = idEstudiantesNotas.indexOf(idEstudiante);
            if (idx !== -1) {
                notasEstudiante = notasPorEstudiante[idx].map(n => ({
                    idCurso: n.idCurso.toNumber(),
                    calificacion: n.calificacion.toNumber()
                }));
            }

            for (let cert of certificadosEst) {
                const idCurso = cert.idCurso.toNumber();
                const curso = cursos.find(c => c.id.toNumber() === idCurso);
                const nombreCurso = curso ? curso.nombre : "Desconocido";

                const notaCurso = notasEstudiante.find(n => n.idCurso === idCurso);
                const calificacion = notaCurso ? notaCurso.calificacion : 0;
                const estadoTexto = calificacion >= 70 ? "Aprobado" : "Reprobado";

                body.append(`
                    <tr>
                        <td>${est.name}</td>
                        <td>${est.wallet}</td>
                        <td>${est.phone}</td>
                        <td>${nombreCurso}</td>
                        <td>${calificacion}</td>
                        <td>${estadoTexto}</td>
                    </tr>
                `);
            }
        }
    }

    $("#example").DataTable({
        destroy: true,
        lengthChange: false,
        buttons: ['copy', 'excel', 'csv', 'pdf', 'colvis']
    }).buttons().container().appendTo('#example_wrapper .col-md-6:eq(0)');
}


$(document).ready(async function() {
    await initContratos();
    await cargarDatos();
});
