// --- Variables globales ---
let provider;
let signer;
let contratoNotas;
let contratoEstudiantes;
let contratoCursos;
let contratoCertificados;
let adminAddress;
let estudiantes = [];
let cursos = [];
let todasNotas = [];

// --- Conectar a MetaMask ---
async function connect() {
    if (!window.ethereum) return alert("⚠️ Instala MetaMask");

    await ethereum.request({ method: "eth_requestAccounts" });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();

    // Inicializar contratos
    contratoNotas = new ethers.Contract(registroNotasAddress, registroNotasABI, signer);
    contratoEstudiantes = new ethers.Contract(registroEstudiantesAddress, registroEstudiantesABI, signer);
    contratoCursos = new ethers.Contract(registroCursosAddress, registroCursosABI, signer);
    contratoCertificados = new ethers.Contract(registroCertificadosAddress, registroCertificadosABI, signer);

    const cuenta = await signer.getAddress();
    console.log("✅ Conectado a MetaMask:", cuenta);

    try {
        adminAddress = await contratoEstudiantes.admin();
        console.log("Admin del contrato:", adminAddress);
    } catch (err) {
        console.error("❌ No se pudo obtener admin del contrato:", err);
    }

    await verificarAdmin();

    // Detectar cambio de cuenta
    window.ethereum.on("accountsChanged", async (accounts) => {
        if (accounts.length > 0) {
            signer = provider.getSigner();
            contratoNotas = new ethers.Contract(registroNotasAddress, registroNotasABI, signer);
            contratoEstudiantes = new ethers.Contract(registroEstudiantesAddress, registroEstudiantesABI, signer);
            contratoCursos = new ethers.Contract(registroCursosAddress, registroCursosABI, signer);
            contratoCertificados = new ethers.Contract(registroCertificadosAddress, registroCertificadosABI, signer);
            console.log("🔄 Cambiaste de cuenta:", accounts[0]);
            await verificarAdmin();
        }
    });

    await llenarSelectEstudiantes();
    await llenarSelectCursos();
}

// --- Verificar admin ---
async function verificarAdmin() {
    if (!contratoNotas || !adminAddress) return;
    const cuenta = await signer.getAddress();
    const esAdmin = cuenta.toLowerCase() === adminAddress.toLowerCase();

    const btnRegistrar = document.getElementById("Registrar");
    if (btnRegistrar) btnRegistrar.disabled = !esAdmin;

    console.log("Cuenta conectada:", cuenta);
    console.log("Admin contrato :", adminAddress);
    console.log(esAdmin ? "✅ Eres admin" : "⚠️ No eres admin");
}

// --- Llenar selects ---
async function llenarSelectEstudiantes() {
    try {
        estudiantes = await contratoEstudiantes.getAllStudents();
        const select = document.getElementById("nombreEstudiante");
        if (!select) return;

        select.innerHTML = "<option value=''>-- Selecciona un estudiante --</option>";
        estudiantes.forEach(e => {
            if (!e.exists) return;
            const option = document.createElement("option");
            option.value = e.id; // usamos id del estudiante
            option.textContent = e.name;
            select.appendChild(option);
        });
    } catch (err) {
        console.error("❌ No se pudieron cargar los estudiantes:", err);
    }
}

async function llenarSelectCursos() {
    try {
        cursos = await contratoCursos.obtenerCursos();
        const select = document.getElementById("nombreCurso");
        if (!select) return;

        select.innerHTML = "<option value=''>-- Selecciona un curso --</option>";
        cursos.forEach(c => {
            if (!c.existe) return;
            const option = document.createElement("option");
            option.value = c.id; // asumimos que curso tiene un id
            option.textContent = c.nombre;
            select.appendChild(option);
        });
    } catch (err) {
        console.error("❌ No se pudieron cargar los cursos:", err);
    }
}

// --- Registrar nota ---
async function registrarNota(event) {
    event.preventDefault();
    const idEstudiante = parseInt(document.getElementById("nombreEstudiante").value);
    const idCurso = parseInt(document.getElementById("nombreCurso").value);
    const calificacion = parseInt(document.getElementById("calificacion").value);

    if (isNaN(idEstudiante) || isNaN(idCurso) || isNaN(calificacion)) {
        return alert("Completa todos los campos correctamente");
    }
    if (calificacion < 0 || calificacion > 100) {
        return alert("La nota debe ser un valor entre 0 y 100");
    }

    try {
        const tx = await contratoNotas.asignarNota(idEstudiante, idCurso, calificacion);
        await tx.wait();
        alert("✅ Nota registrada correctamente!");
        limpiarCampos();
        mostrarNotas();
    } catch (err) {
        console.error("❌ Error al registrar nota:", err);
        alert("Error al registrar nota");
    }
}

// --- Mostrar todas las notas ---
async function mostrarNotas() {
    if (!contratoNotas) await connect();

    try {
        const result = await contratoNotas.obtenerTodasNotas();
        const estudiantesIds = result[0]; // array de BigNumbers
        const notasArray = result[1];     // array de arrays de notas

        const container = document.getElementById("tablainfo");
        if (!container) return;

        let table = container.querySelector("table");
        if (!table) {
            table = document.createElement("table");
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>ID Estudiante</th>
                        <th>Nombre Estudiante</th>
                        <th>ID Curso</th>
                        <th>Nombre Curso</th>
                        <th>Calificación</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;
            container.appendChild(table);
        }

        const tbody = table.querySelector("tbody");
        tbody.innerHTML = "";

        for (let i = 0; i < estudiantesIds.length; i++) {
            const idEstudianteNum = estudiantesIds[i].toNumber();
            const estudiante = estudiantes.find(e => e.id.toNumber() === idEstudianteNum);
            const notas = notasArray[i];

            notas.forEach(nota => {
                const idCursoNum = nota.idCurso.toNumber();
                const calificacionNum = nota.calificacion.toNumber();

                const curso = cursos.find(c => c.id.toNumber() === idCursoNum);

                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${estudiante ? estudiante.id.toNumber() : idEstudianteNum}</td>
                    <td>${estudiante ? estudiante.name : "Desconocido"}</td>
                    <td>${curso ? curso.id.toNumber() : idCursoNum}</td>
                    <td>${curso ? curso.nombre : "Desconocido"}</td>
                    <td>${calificacionNum}</td>
                `;
                tbody.appendChild(tr);
            });
        }

        // Activar selección de fila
        activarSeleccionTabla();
    } catch (err) {
        console.error("❌ Error al mostrar notas:", err);
    }
}

// --- Activar selección de fila para llenar inputs ---
function activarSeleccionTabla() {
    const table = document.querySelector("#tablainfo table tbody");
    if (!table) return;

    table.querySelectorAll("tr").forEach(tr => {
        tr.addEventListener("click", () => {
            const tds = tr.querySelectorAll("td");

            const idEstudiante = parseInt(tds[0].textContent);
            const idCurso = parseInt(tds[2].textContent);
            const calificacion = parseInt(tds[4].textContent);

            if (isNaN(calificacion) || calificacion < 0 || calificacion > 100) {
                return alert("No se puede generar certificado sin nota válida (0-100)");
            }

            const selEstudiante = document.getElementById("nombreEstudiante");
            const selCurso = document.getElementById("nombreCurso");
            const inputNota = document.getElementById("calificacion");

            selEstudiante.value = idEstudiante;
            selCurso.value = idCurso;
            inputNota.value = calificacion;

            selEstudiante.disabled = true;
            selCurso.disabled = true;
            inputNota.disabled = true;
        });
    });
}

// --- Limpiar campos ---
function limpiarCampos() {
    const selEstudiante = document.getElementById("nombreEstudiante");
    const selCurso = document.getElementById("nombreCurso");
    const inputNota = document.getElementById("calificacion");

    if (selEstudiante) {
        selEstudiante.selectedIndex = 0;
        selEstudiante.disabled = false;
    }
    if (selCurso) {
        selCurso.selectedIndex = 0;
        selCurso.disabled = false;
    }
    if (inputNota) {
        inputNota.value = "";
        inputNota.disabled = false;
    }
}

// --- Botones ---
document.getElementById("Registrar")?.addEventListener("click", registrarNota);
document.getElementById("Limpiar")?.addEventListener("click", limpiarCampos);
document.getElementById("Actualizar")?.addEventListener("click", async () => {
    const idEstudiante = parseInt(document.getElementById("nombreEstudiante").value);
    const idCurso = parseInt(document.getElementById("nombreCurso").value);
    const calificacion = parseInt(document.getElementById("calificacion").value);

    if (isNaN(idEstudiante) || isNaN(idCurso) || isNaN(calificacion)) {
        return alert("Completa todos los campos correctamente");
    }

    if (calificacion < 0 || calificacion > 100) {
        return alert("La nota debe ser un valor entre 0 y 100");
    }

    const estudiante = estudiantes.find(e => e.id.toNumber() === idEstudiante);
    if (!estudiante) return alert("Estudiante no encontrado");

    const curso = cursos.find(c => c.id.toNumber() === idCurso);
    if (!curso) return alert("Curso no encontrado");

    const estado = calificacion >= 70 ? "Aprobado" : "Reprobado";
    const fechaEmision = new Date().toLocaleDateString();

    try {
        const tx = await contratoCertificados.emitirCertificado(
            idEstudiante,
            idCurso,
            fechaEmision
        );
        await tx.wait();

        alert(`✅ Certificado generado correctamente!\nEstado: ${estado}\nEstudiante: ${estudiante.name}\nCurso: ${curso.nombre}\nWallet: ${estudiante.wallet}\nTeléfono: ${estudiante.phone}`);
    } catch (err) {
        console.error("❌ Error al registrar certificado:", err);
        alert("Error al generar el certificado");
    }
});

// --- Inicializar ---
window.addEventListener("load", async () => {
    await connect();
    await mostrarNotas();
});
