let provider;
let signer;
let contratoCurso;


async function conectarCurso() {
    if (window.ethereum) {
        await ethereum.request({ method: "eth_requestAccounts" });
        provider = new ethers.providers.Web3Provider(window.ethereum);
        signer = provider.getSigner();
        contratoCurso = new ethers.Contract(registroCursosAddress, registroCursosABI, signer);
        console.log("✅ Conectado a MetaMask (Cursos):", await signer.getAddress());
    } else {
        alert("⚠️ Instala MetaMask para continuar");
    }
}

async function registrarCurso(event) {
    event.preventDefault();

    const nombre = document.getElementById("nombreCurso").value.trim();
    const descripcion = document.getElementById("descripcionCurso").value.trim();

    if (!nombre || !descripcion) {
        alert("Por favor completa todos los campos");
        return;
    }

    try {
        if (!contratoCurso) await conectarCurso();

        const tx = await contratoCurso.agregarCurso(nombre, descripcion);
        await tx.wait();

        alert("✅ Curso registrado correctamente!");
        limpiarCamposCurso();
        mostrarCursos();
    } catch (err) {
        console.error("❌ Error en registro de curso:", err);
        alert("Error al registrar curso (revisa la consola para más detalles)");
    }
}

async function actualizarCurso(event) {
    event.preventDefault();

    const id = document.getElementById("idCurso").value.trim();
    const nombre = document.getElementById("nombreCurso").value.trim();
    const descripcion = document.getElementById("descripcionCurso").value.trim();

    if (!id || !nombre || !descripcion) {
        alert("Por favor completa todos los campos");
        return;
    }

    try {
        if (!contratoCurso) await conectarCurso();

        const tx = await contratoCurso.actualizarCurso(id, nombre, descripcion);
        await tx.wait();

        alert("✅ Curso actualizado correctamente!");
        limpiarCamposCurso();
        mostrarCursos();
    } catch (err) {
        console.error("❌ Error en actualización de curso:", err);
        alert("Error al actualizar curso (revisa la consola para más detalles)");
    }
}

async function eliminarCurso(event) {
    event.preventDefault();

    const id = document.getElementById("idCurso").value.trim();
    if (!id) {
        alert("Por favor ingresa el ID del curso");
        return;
    }

    try {
        if (!contratoCurso) await conectarCurso();

        const tx = await contratoCurso.eliminarCurso(id);
        await tx.wait();

        alert("✅ Curso eliminado correctamente!");
        limpiarCamposCurso();
        mostrarCursos();
    } catch (err) {
        console.error("❌ Error al eliminar curso:", err);
        alert("Error al eliminar curso (revisa la consola para más detalles)");
    }
}

function limpiarCamposCurso() {
    document.getElementById("idCurso").value = "";
    document.getElementById("nombreCurso").value = "";
    document.getElementById("descripcionCurso").value = "";
}

async function mostrarCursos() {
    try {
        if (!contratoCurso) await conectarCurso();

        const cursos = await contratoCurso.obtenerCursos();
        const container = document.getElementById("tablainfo");

        let table = container.querySelector("table");
        if (!table) {
            table = document.createElement("table");
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;
            container.appendChild(table);
        }

        const tbody = table.querySelector("tbody");
        tbody.innerHTML = ""; 

        cursos.forEach(c => {
            if (c.existe) {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${c.id}</td>
                    <td>${c.nombre}</td>
                    <td>${c.descripcion}</td>
                `;

                tr.addEventListener("click", () => {
                    document.getElementById("idCurso").value = c.id;
                    document.getElementById("nombreCurso").value = c.nombre;
                    document.getElementById("descripcionCurso").value = c.descripcion;
                });

                tbody.appendChild(tr);
            }
        });
    } catch (err) {
        console.error("❌ Error al mostrar cursos:", err);
    }
}

document.getElementById("Registrar").addEventListener("click", registrarCurso);
document.getElementById("Actualizar").addEventListener("click", actualizarCurso);
document.getElementById("Eliminar").addEventListener("click", eliminarCurso);
document.getElementById("Ver").addEventListener("click", mostrarCursos);
document.getElementById("Limpiar").addEventListener("click", limpiarCamposCurso);
