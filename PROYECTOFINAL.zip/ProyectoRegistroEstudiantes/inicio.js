document.getElementById("Estudiantes").addEventListener("click", function() {
    window.location.href = "RegistroEstudiantes.html"; 
  });

  document.getElementById("Cursos").addEventListener("click", function() {
    window.location.href = "Cursos.html"; 
  });

  document.getElementById("Matriculas").addEventListener("click", function() {
    window.location.href = "Matriculas.html"; 
  });

  document.getElementById("Notas").addEventListener("click", function() {
    window.location.href = "Notas.html"; 
  });

  document.getElementById("Certificados").addEventListener("click", function() {
    window.location.href = "Certificados.html"; 
  });

  
