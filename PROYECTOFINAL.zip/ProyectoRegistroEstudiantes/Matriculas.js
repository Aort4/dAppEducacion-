// --- Variables globales ---
let provider;
let signer;
let contratoMatriculas;
let contratoEstudiantes;
let contratoCursos;
let adminAddress;
let matriculas = [];
let estudiantes = [];
let cursos = [];
async function connect() {
    if (!window.ethereum) return alert("⚠️ Instala MetaMask");

    await ethereum.request({ method: "eth_requestAccounts" });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();

    contratoMatriculas = new ethers.Contract(registroMatriculasAddress, registroMatriculasABI, signer);
    contratoEstudiantes = new ethers.Contract(registroEstudiantesAddress, registroEstudiantesABI, signer);
    contratoCursos = new ethers.Contract(registroCursosAddress, registroCursosABI, signer);

    const cuenta = await signer.getAddress();
    console.log("✅ Conectado a MetaMask:", cuenta);

    try {
        adminAddress = await contratoEstudiantes.admin();
        console.log("Admin del contrato:", adminAddress);
    } catch (err) {
        console.error("❌ No se pudo obtener admin del contrato:", err);
    }

    await verificarAdmin();

    window.ethereum.on("accountsChanged", async (accounts) => {
        if (accounts.length > 0) {
            signer = provider.getSigner();
            contratoMatriculas = new ethers.Contract(registroMatriculasAddress, registroMatriculasABI, signer);
            console.log("🔄 Cambiaste de cuenta:", accounts[0]);
            await verificarAdmin();
        }
    });

    await llenarSelectEstudiantes();
    await llenarSelectCursos();

    document.getElementById("nombreEstudiante").addEventListener("change", (event) => {
        const wallet = event.target.value;
        document.getElementById("walletEstudiante").value = wallet || "";
    });
}

async function verificarAdmin() {
    if (!contratoMatriculas || !adminAddress) return;
    const cuenta = await signer.getAddress();
    const esAdmin = cuenta.toLowerCase() === adminAddress.toLowerCase();

    document.getElementById("Registrar").disabled = !esAdmin;
    document.getElementById("Eliminar").disabled = !esAdmin;

    console.log("Cuenta conectada:", cuenta);
    console.log("Admin contrato :", adminAddress);
    console.log(esAdmin ? "✅ Eres admin" : "⚠️ No eres admin");
}

async function llenarSelectEstudiantes() {
    try {
        estudiantes = await contratoEstudiantes.getAllStudents();
        const select = document.getElementById("nombreEstudiante");
        select.innerHTML = "<option value=''>-- Selecciona un estudiante --</option>";

        estudiantes.forEach(e => {
            if (!e.exists) return;
            const option = document.createElement("option");
            option.value = e.wallet; 
            option.textContent = e.name;
            select.appendChild(option);
        });
    } catch (err) {
        console.error("❌ No se pudieron cargar los estudiantes:", err);
    }
}

async function llenarSelectCursos() {
    try {
        cursos = await contratoCursos.obtenerCursos();
        const select = document.getElementById("nombreCurso");
        select.innerHTML = "<option value=''>-- Selecciona un curso --</option>";

        cursos.forEach(c => {
            if (!c.existe) return;
            const option = document.createElement("option");
            option.value = c.nombre;
            option.textContent = c.nombre;
            select.appendChild(option);
        });
    } catch (err) {
        console.error("❌ No se pudieron cargar los cursos:", err);
    }
}

// --- Registrar matrícula ---
async function registrarMatricula(event) {
    event.preventDefault();
    const nombre = document.getElementById("nombreMatricula").value.trim();
    const estudianteWallet = document.getElementById("walletEstudiante").value; // Tomamos del input
    const estudianteNombre = estudiantes.find(e => e.wallet === estudianteWallet)?.name || "";
    const cursoNombre = document.getElementById("nombreCurso").value;
    const precio = parseFloat(document.getElementById("PrecioCurso").value);

    if (!nombre || !estudianteWallet || !estudianteNombre || !cursoNombre || isNaN(precio)) {
        return alert("Completa todos los campos correctamente");
    }

    try {
        const tx = await contratoMatriculas.registrarMatricula(
            nombre,
            estudianteNombre,
            estudianteWallet,
            cursoNombre,
            { value: ethers.utils.parseEther(precio.toString()) }
        );
        await tx.wait();
        alert("✅ Matrícula registrada correctamente!");
        limpiarCampos();
        mostrarMatriculas();
    } catch (err) {
        console.error("❌ Error al registrar matrícula:", err);
        alert("Error al registrar matrícula");
    }
}

// --- Actualizar matrícula ---
async function actualizarMatricula(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById("idMatricula").value);
    const nuevoNombre = document.getElementById("nombreMatricula").value.trim();
    const nuevoPrecio = parseFloat(document.getElementById("PrecioCurso").value);

    if (!id || !nuevoNombre || isNaN(nuevoPrecio)) {
        return alert("Completa todos los campos correctamente");
    }

    try {
        const tx = await contratoMatriculas.updateMatricula(
            id,
            nuevoNombre,
            ethers.utils.parseEther(nuevoPrecio.toString())
        );
        await tx.wait();
        alert("✅ Matrícula actualizada correctamente!");
        limpiarCampos();
        mostrarMatriculas();
    } catch (err) {
        console.error("❌ Error al actualizar matrícula:", err);
        alert("Error al actualizar matrícula");
    }
}

// --- Eliminar matrícula ---
async function eliminarMatricula(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById("idMatricula").value);
    if (!id) return alert("Ingresa el ID de la matrícula");

    try {
        const tx = await contratoMatriculas.eliminarMatricula(id);
        await tx.wait();
        alert("✅ Matrícula eliminada correctamente!");
        limpiarCampos();
        mostrarMatriculas();
    } catch (err) {
        console.error("❌ Error al eliminar matrícula:", err);
        alert("Error al eliminar matrícula");
    }
}

// --- Mostrar matrículas ---
async function mostrarMatriculas() {
    if (!contratoMatriculas) await connect();

    try {
        matriculas = await contratoMatriculas.getAllMatriculas();
        const container = document.getElementById("tablainfo");
        let table = container.querySelector("table");

        if (!table) {
            table = document.createElement("table");
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Estudiante</th>
                        <th>Wallet</th>
                        <th>Curso</th>
                        <th>Precio (ETH)</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;
            container.appendChild(table);
        }

        const tbody = table.querySelector("tbody");
        tbody.innerHTML = "";

        matriculas.forEach(m => {
            if (!m.exists) return;
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${m.id}</td>
                <td>${m.nombreMatricula}</td>
                <td>${m.nombreEstudiante}</td>
                <td>${m.walletEstudiante}</td>
                <td>${m.nombreCurso}</td>
                <td>${ethers.utils.formatEther(m.precioPagado.toString())}</td>
            `;
            tr.addEventListener("click", () => {
                document.getElementById("idMatricula").value = m.id;
                document.getElementById("nombreMatricula").value = m.nombreMatricula;
                document.getElementById("PrecioCurso").value = ethers.utils.formatEther(m.precioPagado.toString());
                document.getElementById("nombreEstudiante").value = m.walletEstudiante;
                document.getElementById("walletEstudiante").value = m.walletEstudiante; // Actualizamos wallet
                document.getElementById("nombreCurso").value = m.nombreCurso;
            });
            tbody.appendChild(tr);
        });
    } catch (err) {
        console.error("❌ Error al mostrar matrículas:", err);
    }
}

// --- Limpiar campos ---
function limpiarCampos() {
    document.getElementById("idMatricula").value = "";
    document.getElementById("nombreMatricula").value = "";
    document.getElementById("PrecioCurso").value = "";
    document.getElementById("nombreEstudiante").selectedIndex = 0;
    document.getElementById("walletEstudiante").value = "";
    document.getElementById("nombreCurso").selectedIndex = 0;
}

// --- Listeners ---
document.getElementById("Registrar").addEventListener("click", registrarMatricula);
document.getElementById("Eliminar").addEventListener("click", eliminarMatricula);
document.getElementById("Limpiar").addEventListener("click", limpiarCampos);

// --- Inicializar ---
window.addEventListener("load", async () => {
    await connect();
    await mostrarMatriculas();
});
