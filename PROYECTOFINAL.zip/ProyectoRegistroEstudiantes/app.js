
const registroEstudiantesAddress = "0x632310d631951b9128b402da20A3BcE233a589C9"; 
const registroCursosAddress = "0x414cD4DD3EAC782eB6bA9918980A6e5ae2EC9D12"; 
const registroNotasAddress = "0x8bB093bc7078CE0a0fF963df97094258641Bd48F"; 
const registroMatriculasAddress = "0x18Ef2353cCaba930f57f133f39419fb307117fb6";
const registroCertificadosAddress = "0xCb42B88ABB3728004aF647fBF1807e6B7BE11cB1"; 

//ABI ESTUDIANTES
const registroEstudiantesABI = [
  {
    "anonymous": false,
    "inputs": [
      {"indexed": true,"internalType": "uint256","name": "id","type": "uint256"},
      {"indexed": true,"internalType": "address","name": "wallet","type": "address"},
      {"indexed": false,"internalType": "string","name": "name","type": "string"},
      {"indexed": false,"internalType": "string","name": "phone","type": "string"}
    ],
    "name": "StudentRegistered",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {"indexed": true,"internalType": "uint256","name": "id","type": "uint256"},
      {"indexed": true,"internalType": "address","name": "wallet","type": "address"},
      {"indexed": false,"internalType": "string","name": "name","type": "string"},
      {"indexed": false,"internalType": "string","name": "phone","type": "string"}
    ],
    "name": "StudentUpdated",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs":[
      {"indexed": true,"internalType":"uint256","name":"id","type":"uint256"},
      {"indexed": true,"internalType":"address","name":"wallet","type":"address"}
    ],
    "name": "StudentDeleted",
    "type": "event"
  },
  {
    "inputs": [
      {"internalType": "address","name": "wallet","type": "address"},
      {"internalType": "string","name": "name","type": "string"},
      {"internalType": "string","name": "phone","type": "string"}
    ],
    "name": "registerStudent",
    "outputs":[{"internalType":"uint256","name":"","type":"uint256"}],
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "inputs":[{"internalType":"address","name":"wallet","type":"address"}],
    "name":"getStudentByWallet",
    "outputs":[
      {"internalType":"uint256","name":"","type":"uint256"},
      {"internalType":"string","name":"","type":"string"},
      {"internalType":"address","name":"","type":"address"},
      {"internalType":"string","name":"","type":"string"}
    ],
    "stateMutability":"view",
    "type":"function"
  },
  {
    "inputs":[{"internalType":"uint256","name":"id","type":"uint256"},{"internalType":"string","name":"newName","type":"string"},{"internalType":"string","name":"newPhone","type":"string"}],
    "name":"updateStudent",
    "outputs":[],
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "inputs":[{"internalType":"address","name":"wallet","type":"address"}],
    "name":"deleteStudent",
    "outputs":[],
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "inputs":[],
    "name":"getAllStudents",
    "outputs":[{"components":[
      {"internalType":"uint256","name":"id","type":"uint256"},
      {"internalType":"string","name":"name","type":"string"},
      {"internalType":"string","name":"phone","type":"string"},
      {"internalType":"address","name":"wallet","type":"address"},
      {"internalType":"bool","name":"exists","type":"bool"}
    ],"internalType":"struct REGISTROESTUDIANTES.Student[]","name":"","type":"tuple[]"}],
    "stateMutability":"view",
    "type":"function"
  },
  {
    "inputs":[],
    "name":"admin",
    "outputs":[{"internalType":"address","name":"","type":"address"}],
    "stateMutability":"view",
    "type":"function"
  }
];

//BI CURSOS
const registroCursosABI = [
  {
    "anonymous": false,
    "inputs":[
      {"indexed":true,"internalType":"uint256","name":"id","type":"uint256"},
      {"indexed":false,"internalType":"string","name":"nombre","type":"string"},
      {"indexed":false,"internalType":"string","name":"descripcion","type":"string"}
    ],
    "name":"CursoAgregado",
    "type":"event"
  },
  {
    "anonymous": false,
    "inputs":[
      {"indexed":true,"internalType":"uint256","name":"id","type":"uint256"},
      {"indexed":false,"internalType":"string","name":"nombre","type":"string"},
      {"indexed":false,"internalType":"string","name":"descripcion","type":"string"}
    ],
    "name":"CursoActualizado",
    "type":"event"
  },
  {
    "anonymous":false,
    "inputs":[{"indexed":true,"internalType":"uint256","name":"id","type":"uint256"}],
    "name":"CursoEliminado",
    "type":"event"
  },
  {
    "inputs":[{"internalType":"string","name":"nombre","type":"string"},{"internalType":"string","name":"descripcion","type":"string"}],
    "name":"agregarCurso",
    "outputs":[],
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "inputs":[{"internalType":"uint256","name":"id","type":"uint256"},{"internalType":"string","name":"nombre","type":"string"},{"internalType":"string","name":"descripcion","type":"string"}],
    "name":"actualizarCurso",
    "outputs":[],
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "inputs":[{"internalType":"uint256","name":"id","type":"uint256"}],
    "name":"eliminarCurso",
    "outputs":[],
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "inputs":[],
    "name":"obtenerCursos", 
    "outputs":[{"components":[
      {"internalType":"uint256","name":"id","type":"uint256"},
      {"internalType":"string","name":"nombre","type":"string"},
      {"internalType":"string","name":"descripcion","type":"string"},
      {"internalType":"bool","name":"existe","type":"bool"}
    ],"internalType":"struct RegistroCursos.Curso[]","name":"","type":"tuple[]"}],
    "stateMutability":"view",
    "type":"function"
  }
];

// ABI de Matrículas
const registroMatriculasABI = [
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "uint256", "name": "id", "type": "uint256" },
      { "indexed": true, "internalType": "address", "name": "walletEstudiante", "type": "address" },
      { "indexed": false, "internalType": "string", "name": "nombreMatricula", "type": "string" },
      { "indexed": false, "internalType": "string", "name": "nombreEstudiante", "type": "string" },
      { "indexed": false, "internalType": "string", "name": "nombreCurso", "type": "string" },
      { "indexed": false, "internalType": "uint256", "name": "precioPagado", "type": "uint256" }
    ],
    "name": "MatriculaRegistrada",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "uint256", "name": "id", "type": "uint256" },
      { "indexed": true, "internalType": "address", "name": "walletEstudiante", "type": "address" }
    ],
    "name": "MatriculaEliminada",
    "type": "event"
  },
  {
    "inputs": [
      { "internalType": "string", "name": "nombreMatricula", "type": "string" },
      { "internalType": "string", "name": "nombreEstudiante", "type": "string" },
      { "internalType": "address", "name": "walletEstudiante", "type": "address" },
      { "internalType": "string", "name": "nombreCurso", "type": "string" }
    ],
    "name": "registrarMatricula",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "id", "type": "uint256" }],
    "name": "eliminarMatricula",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "id", "type": "uint256" }],
    "name": "getMatricula",
    "outputs": [
      {
        "components": [
          { "internalType": "uint256", "name": "id", "type": "uint256" },
          { "internalType": "string", "name": "nombreMatricula", "type": "string" },
          { "internalType": "string", "name": "nombreEstudiante", "type": "string" },
          { "internalType": "address", "name": "walletEstudiante", "type": "address" },
          { "internalType": "string", "name": "nombreCurso", "type": "string" },
          { "internalType": "uint256", "name": "precioPagado", "type": "uint256" },
          { "internalType": "bool", "name": "exists", "type": "bool" }
        ],
        "internalType": "struct REGISTROMATRICULAS.Matricula",
        "name": "",
        "type": "tuple"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getAllMatriculas",
    "outputs": [
      {
        "components": [
          { "internalType": "uint256", "name": "id", "type": "uint256" },
          { "internalType": "string", "name": "nombreMatricula", "type": "string" },
          { "internalType": "string", "name": "nombreEstudiante", "type": "string" },
          { "internalType": "address", "name": "walletEstudiante", "type": "address" },
          { "internalType": "string", "name": "nombreCurso", "type": "string" },
          { "internalType": "uint256", "name": "precioPagado", "type": "uint256" },
          { "internalType": "bool", "name": "exists", "type": "bool" }
        ],
        "internalType": "struct REGISTROMATRICULAS.Matricula[]",
        "name": "",
        "type": "tuple[]"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

// ABI de Notas
const registroNotasABI = [
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "uint256", "name": "idEstudiante", "type": "uint256" },
      { "indexed": true, "internalType": "uint256", "name": "idCurso", "type": "uint256" },
      { "indexed": false, "internalType": "uint256", "name": "calificacion", "type": "uint256" }
    ],
    "name": "NotaAsignada",
    "type": "event"
  },
  {
    "inputs": [
      { "internalType": "uint256", "name": "idEstudiante", "type": "uint256" },
      { "internalType": "uint256", "name": "idCurso", "type": "uint256" },
      { "internalType": "uint256", "name": "calificacion", "type": "uint256" }
    ],
    "name": "asignarNota",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "uint256", "name": "idEstudiante", "type": "uint256" }
    ],
    "name": "obtenerNotas",
    "outputs": [
      {
        "components": [
          { "internalType": "uint256", "name": "idCurso", "type": "uint256" },
          { "internalType": "uint256", "name": "calificacion", "type": "uint256" }
        ],
        "internalType": "struct REGISTRONOTAS.Nota[]",
        "name": "",
        "type": "tuple[]"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "obtenerTodasNotas",
    "outputs": [
      { "internalType": "uint256[]", "name": "", "type": "uint256[]" },
      { "internalType": "tuple[][]", "name": "", "type": "tuple[][]",
        "components": [
          { "internalType": "uint256", "name": "idCurso", "type": "uint256" },
          { "internalType": "uint256", "name": "calificacion", "type": "uint256" }
        ]
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "admin",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  }
];

// ABI de Certificados
const registroCertificadosABI = [
  {
    "anonymous": false,
    "inputs": [
      {"indexed": true, "internalType": "uint256", "name": "id", "type": "uint256"},
      {"indexed": true, "internalType": "uint256", "name": "idEstudiante", "type": "uint256"},
      {"indexed": true, "internalType": "uint256", "name": "idCurso", "type": "uint256"}
    ],
    "name": "CertificadoEmitido",
    "type": "event"
  },
  {
    "inputs": [
      {"internalType": "uint256", "name": "idEstudiante", "type": "uint256"},
      {"internalType": "uint256", "name": "idCurso", "type": "uint256"},
      {"internalType": "string", "name": "fechaEmision", "type": "string"}
    ],
    "name": "emitirCertificado",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "uint256", "name": "id", "type": "uint256"}],
    "name": "obtenerCertificado",
    "outputs": [{
      "components": [
        {"internalType": "uint256", "name": "id", "type": "uint256"},
        {"internalType": "uint256", "name": "idEstudiante", "type": "uint256"},
        {"internalType": "uint256", "name": "idCurso", "type": "uint256"},
        {"internalType": "string", "name": "fechaEmision", "type": "string"},
        {"internalType": "bool", "name": "valido", "type": "bool"}
      ],
      "internalType": "struct CertificateRegistry.Certificado",
      "name": "",
      "type": "tuple"
    }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "obtenerTodosCertificados",
    "outputs": [{
      "components": [
        {"internalType": "uint256", "name": "id", "type": "uint256"},
        {"internalType": "uint256", "name": "idEstudiante", "type": "uint256"},
        {"internalType": "uint256", "name": "idCurso", "type": "uint256"},
        {"internalType": "string", "name": "fechaEmision", "type": "string"},
        {"internalType": "bool", "name": "valido", "type": "bool"}
      ],
      "internalType": "struct CertificateRegistry.Certificado[]",
      "name": "",
      "type": "tuple[]"
    }],
    "stateMutability": "view",
    "type": "function"
  }
];
